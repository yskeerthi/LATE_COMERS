import React from 'react'

// const data = JSON.parse(localStorage.getItem("TodayInData"))
// console.log(data)
function empty() {
  return (
    <h1>hai</h1>
  )
}

export default empty